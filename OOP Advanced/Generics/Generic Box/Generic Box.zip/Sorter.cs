﻿using System.Collections.Generic;

namespace Generic_Box
{
    using System;

    public static class Sorter<T>
        where T : IComparable<T>

    {
        public static void Sort(Box<T> list)
        {
            list.GetData().Sort();
        }
    }
}
