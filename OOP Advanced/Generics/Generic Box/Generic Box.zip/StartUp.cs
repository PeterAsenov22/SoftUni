﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Generic_Box
{
    public class StartUp
    {
        public static void Main()
        {
            //var command = Console.ReadLine();
            //var box = new Box<string>();

            //while (command!="END")
            //{
            //    var cmdArgs = command.Split(new[] {' '}, StringSplitOptions.RemoveEmptyEntries);

            //    switch (cmdArgs[0])
            //    {
            //        case "Add":
            //            box.Add(cmdArgs[1]);
            //            break;
            //        case "Remove":
            //            box.Remove(int.Parse(cmdArgs[1]));
            //            break;
            //        case "Contains":
            //            Console.WriteLine(box.Contains(cmdArgs[1]));                
            //            break;
            //        case "Swap":
            //            box.Swap(int.Parse(cmdArgs[1]),int.Parse(cmdArgs[2]));
            //            break;
            //        case "Greater":
            //            Console.WriteLine(box.CountGreaterThan(cmdArgs[1]));
            //            break;
            //        case "Max":
            //            Console.WriteLine(box.Max());
            //            break;
            //        case "Min":
            //            Console.WriteLine(box.Min());
            //            break;
            //        case "Print":
            //            Console.WriteLine(box.Print());
            //            break;
            //        case "Sort":
            //            Sorter<string>.Sort(box);
            //            break;
            //    }

            //    command = Console.ReadLine();
            //}

            var firstInputParams = Console.ReadLine().Split(new[] {' '}, StringSplitOptions.RemoveEmptyEntries).ToList();
            var town = firstInputParams[firstInputParams.Count - 1];
            firstInputParams.RemoveAt(firstInputParams.Count-1);
            var adress = firstInputParams[firstInputParams.Count-1];
            firstInputParams.RemoveAt(firstInputParams.Count-1);
            var fullName = string.Join(" ", firstInputParams);

            var tuple = new Tuple<string, string, string>(fullName,adress, town);
            Console.WriteLine(tuple.ToString());

            var secondInputParams = Console.ReadLine().Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            var name = secondInputParams[0];
            var beers = int.Parse(secondInputParams[1]);
            var drunkOrNot = secondInputParams[2];
            if (drunkOrNot == "drunk")
            {
                var secondTuple = new Tuple<string, int, bool>(name, beers,true);
                Console.WriteLine(secondTuple.ToString());
            }
            else
            {
                var secondTuple = new Tuple<string, int,bool>(name, beers,false);
                Console.WriteLine(secondTuple.ToString());
            }
            
            var thirdInputParams = Console.ReadLine().Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            var personName = thirdInputParams[0];
            var balance = double.Parse(thirdInputParams[1]);
            var bank = thirdInputParams[2];

            var thirdTuple = new Tuple<string,double,string>(personName,balance,bank);
            Console.WriteLine(thirdTuple.ToString());
        }
    }
}
