﻿namespace Generic_Box
{
    public class Tuple<T,T1,T2>
    {
        private T firstItem;
        private T1 secondItem;
        private T2 thirdItem;

        public Tuple(T first, T1 second, T2 third)
        {
            this.firstItem = first;
            this.secondItem = second;
            this.thirdItem = third;
        }

        public override string ToString()
        {
            return $"{firstItem} -> {secondItem} -> {thirdItem}";
        }
    }
}
