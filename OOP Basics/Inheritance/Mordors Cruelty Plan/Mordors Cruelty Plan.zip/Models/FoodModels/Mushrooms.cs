﻿namespace Mordors_Cruelty_Plan.Models.FoodModels
{
    public class Mushrooms : Food
    {
        public Mushrooms(int points) : base(points)
        {
        }
    }
}
