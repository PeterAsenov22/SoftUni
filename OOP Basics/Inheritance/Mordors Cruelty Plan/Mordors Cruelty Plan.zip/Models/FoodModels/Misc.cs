﻿namespace Mordors_Cruelty_Plan.Models.FoodModels
{
    public class Misc : Food
    {
        public Misc(int points) : base(points)
        {
        }
    }
}
