﻿namespace Mordors_Cruelty_Plan.Models.FoodModels
{
    public class Lembas : Food
    {
        public Lembas(int points) : base(points)
        {
        }
    }
}
