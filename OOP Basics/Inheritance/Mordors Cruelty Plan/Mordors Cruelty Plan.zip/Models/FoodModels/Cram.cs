﻿namespace Mordors_Cruelty_Plan.Models.FoodModels
{
    public class Cram : Food
    {
        public Cram(int points) : base(points)
        {
        }
    }
}
