﻿namespace Mordors_Cruelty_Plan.Models.FoodModels
{
    public class Apple : Food
    {
        public Apple(int points) : base(points)
        {
        }
    }
}
