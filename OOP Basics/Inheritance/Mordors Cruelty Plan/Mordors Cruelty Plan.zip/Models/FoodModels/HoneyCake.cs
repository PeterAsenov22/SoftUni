﻿namespace Mordors_Cruelty_Plan.Models.FoodModels
{
    public class HoneyCake : Food
    {
        public HoneyCake(int points) : base(points)
        {
        }
    }
}
