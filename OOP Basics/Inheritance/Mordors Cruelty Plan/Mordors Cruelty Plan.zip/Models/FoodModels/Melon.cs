﻿namespace Mordors_Cruelty_Plan.Models.FoodModels
{
    public class Melon : Food
    {
        public Melon(int points) : base(points)
        {
        }
    }
}
