﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Family
{
    public class Person
    {
        public Person(string name, string birthDay)
        {
            this.Name = name;
            this.Birthday = birthDay;
            this.Parents = new List<Person>();
            this.Children = new List<Person>();
        }

        public string Name { get; }

        public string Birthday { get; }

        public List<Person> Parents { get; }

        public List<Person> Children { get; }

        public override string ToString()
        {
            return $"{this.Name} {this.Birthday}";
        }
    }
}
